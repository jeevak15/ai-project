# Jeevak Khade Portfolio

This is my personal portfolio website hosted on GitHub Pages.

## 🚀 How to Use

1. Upload all files to your GitHub repository
2. Go to Settings → Pages
3. Select branch: main
4. Your site will be live at:
   https://yourusername.github.io/repository-name

## 🛠 Tech Used
- HTML
- CSS

---

Made with ❤️
